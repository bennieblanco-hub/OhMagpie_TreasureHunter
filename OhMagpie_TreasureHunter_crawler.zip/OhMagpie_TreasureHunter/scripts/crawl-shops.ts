/**
 * OhMagpie TreasureHunter — UK Antique Jewellery Shop Crawler
 *
 * Uses Google Places Text Search API to find every antique jeweller
 * in the UK, then inserts them into Supabase.
 *
 * Run with:
 *   npm run crawl
 *
 * Expects .env.local to be present with:
 *   NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
 *   NEXT_PUBLIC_SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 */

import { createClient } from '@supabase/supabase-js'
import { config } from 'dotenv'
import { resolve } from 'path'

// Load .env.local
config({ path: resolve(process.cwd(), '.env.local') })

const MAPS_KEY   = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY!
const SUPA_URL   = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPA_KEY   = process.env.SUPABASE_SERVICE_ROLE_KEY!

if (!MAPS_KEY || !SUPA_URL || !SUPA_KEY) {
  console.error('❌  Missing env vars. Check .env.local')
  process.exit(1)
}

const supabase = createClient(SUPA_URL, SUPA_KEY, { auth: { persistSession: false } })

// ─── Axbridge home coords ──────────────────────────────────────────────────────
const HOME = { lat: 51.2897, lng: -2.8174 }

function distanceMiles(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3958.8
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a = Math.sin(dLat/2)**2
    + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)))
}

// ─── UK cities — comprehensive coverage ───────────────────────────────────────
const UK_CITIES: Array<{ name: string; lat: number; lng: number; county: string }> = [
  // South West
  { name:'Bristol',          lat:51.4545, lng:-2.5879, county:'Bristol' },
  { name:'Bath',             lat:51.3811, lng:-2.3592, county:'Somerset' },
  { name:'Wells',            lat:51.2094, lng:-2.6474, county:'Somerset' },
  { name:'Glastonbury',      lat:51.1431, lng:-2.7162, county:'Somerset' },
  { name:'Taunton',          lat:51.0153, lng:-3.1014, county:'Somerset' },
  { name:'Frome',            lat:51.2295, lng:-2.3196, county:'Somerset' },
  { name:'Weston-super-Mare',lat:51.3462, lng:-2.9773, county:'Somerset' },
  { name:'Exeter',           lat:50.7184, lng:-3.5345, county:'Devon' },
  { name:'Plymouth',         lat:50.3755, lng:-4.1427, county:'Devon' },
  { name:'Truro',            lat:50.2632, lng:-5.0510, county:'Cornwall' },
  { name:'Torquay',          lat:50.4619, lng:-3.5253, county:'Devon' },
  { name:'Totnes',           lat:50.4308, lng:-3.6847, county:'Devon' },
  { name:'Barnstaple',       lat:51.0825, lng:-4.0580, county:'Devon' },
  { name:'Dorchester',       lat:50.7154, lng:-2.4382, county:'Dorset' },
  { name:'Bournemouth',      lat:50.7192, lng:-1.8808, county:'Dorset' },
  { name:'Poole',            lat:50.7157, lng:-1.9872, county:'Dorset' },
  { name:'Sherborne',        lat:50.9450, lng:-2.5164, county:'Dorset' },
  { name:'Salisbury',        lat:51.0693, lng:-1.7943, county:'Wiltshire' },
  { name:'Marlborough',      lat:51.4210, lng:-1.7296, county:'Wiltshire' },
  { name:'Devizes',          lat:51.3573, lng:-1.9969, county:'Wiltshire' },
  // South East
  { name:'London Mayfair',       lat:51.5100, lng:-0.1450, county:'London' },
  { name:'London Notting Hill',  lat:51.5148, lng:-0.2044, county:'London' },
  { name:'London Islington',     lat:51.5390, lng:-0.1027, county:'London' },
  { name:'London Bermondsey',    lat:51.4980, lng:-0.0730, county:'London' },
  { name:'London Marylebone',    lat:51.5240, lng:-0.1600, county:'London' },
  { name:'London Kensington',    lat:51.4994, lng:-0.1937, county:'London' },
  { name:'London Chelsea',       lat:51.4875, lng:-0.1687, county:'London' },
  { name:'London Hatton Garden', lat:51.5186, lng:-0.1085, county:'London' },
  { name:'London Greenwich',     lat:51.4826, lng:-0.0077, county:'London' },
  { name:'London Hampstead',     lat:51.5559, lng:-0.1778, county:'London' },
  { name:'Brighton',         lat:50.8229, lng:-0.1363, county:'East Sussex' },
  { name:'Lewes',            lat:50.8741, lng:0.0104,  county:'East Sussex' },
  { name:'Tunbridge Wells',  lat:51.1323, lng:0.2637,  county:'Kent' },
  { name:'Canterbury',       lat:51.2802, lng:1.0789,  county:'Kent' },
  { name:'Rye',              lat:50.9541, lng:0.7306,  county:'East Sussex' },
  { name:'Petworth',         lat:50.9955, lng:-0.6143, county:'West Sussex' },
  { name:'Arundel',          lat:50.8507, lng:-0.5553, county:'West Sussex' },
  { name:'Guildford',        lat:51.2362, lng:-0.5704, county:'Surrey' },
  { name:'Winchester',       lat:51.0632, lng:-1.3082, county:'Hampshire' },
  { name:'Southampton',      lat:50.9097, lng:-1.4044, county:'Hampshire' },
  { name:'Portsmouth',       lat:50.8198, lng:-1.0880, county:'Hampshire' },
  { name:'Oxford',           lat:51.7520, lng:-1.2577, county:'Oxfordshire' },
  { name:'Woodstock',        lat:51.8474, lng:-1.3559, county:'Oxfordshire' },
  { name:'Henley-on-Thames', lat:51.5354, lng:-0.8993, county:'Oxfordshire' },
  { name:'Windsor',          lat:51.4839, lng:-0.6044, county:'Berkshire' },
  { name:'Reading',          lat:51.4543, lng:-0.9781, county:'Berkshire' },
  { name:'St Albans',        lat:51.7454, lng:-0.3366, county:'Hertfordshire' },
  { name:'Harpenden',        lat:51.8148, lng:-0.3540, county:'Hertfordshire' },
  { name:'Cambridge',        lat:52.2053, lng:0.1218,  county:'Cambridgeshire' },
  { name:'Bury St Edmunds',  lat:52.2469, lng:0.7148,  county:'Suffolk' },
  { name:'Colchester',       lat:51.8959, lng:0.8919,  county:'Essex' },
  { name:'Norwich',          lat:52.6309, lng:1.2974,  county:'Norfolk' },
  // Cotswolds / Midlands
  { name:'Cheltenham',       lat:51.8994, lng:-2.0783, county:'Gloucestershire' },
  { name:'Cirencester',      lat:51.7196, lng:-1.9672, county:'Gloucestershire' },
  { name:'Tetbury',          lat:51.6397, lng:-2.1595, county:'Gloucestershire' },
  { name:'Chipping Campden', lat:52.0559, lng:-1.7792, county:'Gloucestershire' },
  { name:'Bourton-on-the-Water',lat:51.8768,lng:-1.7582,county:'Gloucestershire' },
  { name:'Stow-on-the-Wold', lat:51.9296, lng:-1.7250, county:'Gloucestershire' },
  { name:'Moreton-in-Marsh', lat:51.9890, lng:-1.6902, county:'Gloucestershire' },
  { name:'Stroud',           lat:51.7452, lng:-2.2165, county:'Gloucestershire' },
  { name:'Gloucester',       lat:51.8642, lng:-2.2381, county:'Gloucestershire' },
  { name:'Malvern',          lat:52.1140, lng:-2.3241, county:'Worcestershire' },
  { name:'Worcester',        lat:52.1920, lng:-2.2196, county:'Worcestershire' },
  { name:'Hereford',         lat:52.0567, lng:-2.7158, county:'Herefordshire' },
  { name:'Ludlow',           lat:52.3682, lng:-2.7178, county:'Shropshire' },
  { name:'Shrewsbury',       lat:52.7080, lng:-2.7539, county:'Shropshire' },
  { name:'Stratford-upon-Avon',lat:52.1918,lng:-1.7083,county:'Warwickshire' },
  { name:'Warwick',          lat:52.2821, lng:-1.5841, county:'Warwickshire' },
  { name:'Birmingham',       lat:52.4862, lng:-1.8904, county:'West Midlands' },
  { name:'Solihull',         lat:52.4121, lng:-1.7740, county:'West Midlands' },
  { name:'Coventry',         lat:52.4068, lng:-1.5197, county:'West Midlands' },
  { name:'Leamington Spa',   lat:52.2915, lng:-1.5362, county:'Warwickshire' },
  { name:'Lichfield',        lat:52.6838, lng:-1.8287, county:'Staffordshire' },
  { name:'Nottingham',       lat:52.9548, lng:-1.1581, county:'Nottinghamshire' },
  { name:'Derby',            lat:52.9226, lng:-1.4746, county:'Derbyshire' },
  { name:'Leicester',        lat:52.6369, lng:-1.1398, county:'Leicestershire' },
  { name:'Lincoln',          lat:53.2307, lng:-0.5406, county:'Lincolnshire' },
  { name:'Stamford',         lat:52.6531, lng:-0.4824, county:'Lincolnshire' },
  // North / Yorkshire
  { name:'Leeds',            lat:53.7997, lng:-1.5492, county:'Yorkshire' },
  { name:'York',             lat:53.9590, lng:-1.0815, county:'Yorkshire' },
  { name:'Harrogate',        lat:53.9925, lng:-1.5401, county:'Yorkshire' },
  { name:'Skipton',          lat:53.9619, lng:-2.0174, county:'Yorkshire' },
  { name:'Ilkley',           lat:53.9250, lng:-1.8309, county:'Yorkshire' },
  { name:'Knaresborough',    lat:54.0082, lng:-1.4659, county:'Yorkshire' },
  { name:'Sheffield',        lat:53.3811, lng:-1.4701, county:'Yorkshire' },
  { name:'Bradford',         lat:53.7960, lng:-1.7594, county:'Yorkshire' },
  { name:'Hull',             lat:53.7457, lng:-0.3367, county:'Yorkshire' },
  { name:'Beverley',         lat:53.8404, lng:-0.4333, county:'Yorkshire' },
  { name:'Richmond',         lat:54.4030, lng:-1.7356, county:'North Yorkshire' },
  { name:'Manchester',       lat:53.4808, lng:-2.2426, county:'Greater Manchester' },
  { name:'Salford',          lat:53.4875, lng:-2.2901, county:'Greater Manchester' },
  { name:'Chester',          lat:53.1905, lng:-2.8910, county:'Cheshire' },
  { name:'Knutsford',        lat:53.3025, lng:-2.3715, county:'Cheshire' },
  { name:'Nantwich',         lat:53.0670, lng:-2.5224, county:'Cheshire' },
  { name:'Liverpool',        lat:53.4084, lng:-2.9916, county:'Merseyside' },
  { name:'Lancaster',        lat:54.0465, lng:-2.8007, county:'Lancashire' },
  { name:'Kendal',           lat:54.3237, lng:-2.7449, county:'Cumbria' },
  { name:'Newcastle',        lat:54.9783, lng:-1.6178, county:'Tyne and Wear' },
  { name:'Durham',           lat:54.7761, lng:-1.5733, county:'County Durham' },
  { name:'Barnard Castle',   lat:54.5444, lng:-1.9199, county:'County Durham' },
  // Scotland
  { name:'Edinburgh',        lat:55.9533, lng:-3.1883, county:'Edinburgh' },
  { name:'Glasgow',          lat:55.8642, lng:-4.2518, county:'Glasgow' },
  { name:'Stirling',         lat:56.1165, lng:-3.9369, county:'Stirlingshire' },
  { name:'Perth',            lat:56.3950, lng:-3.4370, county:'Perthshire' },
  { name:'Dundee',           lat:56.4620, lng:-2.9707, county:'Angus' },
  { name:'Aberdeen',         lat:57.1497, lng:-2.0943, county:'Aberdeenshire' },
  { name:'Inverness',        lat:57.4778, lng:-4.2247, county:'Highland' },
  { name:'St Andrews',       lat:56.3398, lng:-2.7967, county:'Fife' },
  // Wales
  { name:'Cardiff',          lat:51.4816, lng:-3.1791, county:'Cardiff' },
  { name:'Abergavenny',      lat:51.8241, lng:-3.0152, county:'Monmouthshire' },
  { name:'Brecon',           lat:51.9465, lng:-3.3868, county:'Powys' },
  { name:'Hay-on-Wye',       lat:52.0736, lng:-3.1265, county:'Powys' },
]

const SEARCH_QUERIES = [
  'antique jewellery shop',
  'antique jewellery dealer',
  'vintage jewellery specialist',
]

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }

async function searchNearby(query: string, lat: number, lng: number, pageToken?: string): Promise<any> {
  const params = new URLSearchParams({
    query: `${query} in UK`,
    location: `${lat},${lng}`,
    radius: '40000',
    key: MAPS_KEY,
    ...(pageToken ? { pagetoken: pageToken } : {}),
  })
  const res = await fetch(`https://maps.googleapis.com/maps/api/place/textsearch/json?${params}`)
  return res.json()
}

async function getDetails(placeId: string): Promise<any> {
  const params = new URLSearchParams({
    place_id: placeId,
    fields: 'name,formatted_address,formatted_phone_number,international_phone_number,website,opening_hours,geometry,address_components',
    key: MAPS_KEY,
  })
  const res = await fetch(`https://maps.googleapis.com/maps/api/place/details/json?${params}`)
  return res.json()
}

function extractPostcode(address: string): string {
  const match = address.match(/[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}/i)
  return match ? match[0].toUpperCase() : ''
}

function extractTown(components: any[]): { town: string; county: string } {
  let town = '', county = ''
  for (const c of components) {
    if (c.types.includes('postal_town')) town = c.long_name
    if (c.types.includes('locality') && !town) town = c.long_name
    if (c.types.includes('administrative_area_level_2')) county = c.long_name
    if (c.types.includes('administrative_area_level_1') && !county) county = c.long_name
  }
  return { town: town || 'Unknown', county: county || 'Unknown' }
}

async function upsertShop(place: any, details: any): Promise<boolean> {
  const loc = place.geometry?.location
  if (!loc) return false

  const lat = loc.lat
  const lng = loc.lng
  const distance = distanceMiles(HOME.lat, HOME.lng, lat, lng)
  const { town, county } = extractTown(details.address_components || [])
  const postcode = extractPostcode(place.formatted_address || '')

  const { error } = await supabase.from('shops').upsert({
    google_place_id: place.place_id,
    name:            place.name,
    raw_address:     place.formatted_address,
    address:         place.formatted_address?.split(',')[0] || '',
    town,
    county,
    postcode,
    lat,
    lng,
    distance_miles:  distance,
    eras:            ['Victorian', 'General'], // default — can be refined later
    type:            'general',
    phone:           details.international_phone_number || details.formatted_phone_number || null,
    website:         details.website || null,
    opening_hours:   details.opening_hours?.weekday_text?.join(' | ') || null,
    notes:           `Found via Google Places. ${place.types?.join(', ') || ''}`,
    verified:        false,
    source:          'google_places',
  }, { onConflict: 'google_place_id' })

  if (error) {
    console.error(`  ❌ Failed to upsert ${place.name}:`, error.message)
    return false
  }
  return true
}

async function crawlCity(city: typeof UK_CITIES[0]) {
  let totalFound = 0
  const seen = new Set<string>()

  for (const query of SEARCH_QUERIES) {
    let pageToken: string | undefined
    let page = 0

    do {
      if (pageToken) await sleep(2500) // Google requires a short wait between page tokens

      const data = await searchNearby(query, city.lat, city.lng, pageToken)

      if (data.status === 'REQUEST_DENIED') {
        console.error('❌  API key invalid or Places API not enabled:', data.error_message)
        process.exit(1)
      }

      if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
        console.log(`    ⚠  ${data.status} for "${query}" near ${city.name}`)
        break
      }

      const results = data.results || []

      for (const place of results) {
        if (seen.has(place.place_id)) continue
        seen.add(place.place_id)

        // Get full details
        await sleep(200) // be polite to the API
        const detailData = await getDetails(place.place_id)
        const details = detailData.result || {}

        const inserted = await upsertShop(place, details)
        if (inserted) {
          totalFound++
          process.stdout.write(`\r  ${city.name}: ${totalFound} shops found`)
        }
      }

      pageToken = data.next_page_token
      page++
    } while (pageToken && page < 3) // max 3 pages (60 results) per query

    await sleep(500)
  }

  return totalFound
}

async function main() {
  console.log('\n🔍  OhMagpie TreasureHunter — UK Shop Crawler')
  console.log('━'.repeat(50))
  console.log(`📍  Home: Axbridge, Somerset`)
  console.log(`🏙  Cities to crawl: ${UK_CITIES.length}`)
  console.log(`🔑  API key: ${MAPS_KEY.slice(0,10)}...`)
  console.log('━'.repeat(50))
  console.log('\nStarting crawl... this will take 15–30 minutes.\n')

  let grandTotal = 0

  for (let i = 0; i < UK_CITIES.length; i++) {
    const city = UK_CITIES[i]
    process.stdout.write(`[${String(i+1).padStart(2,'0')}/${UK_CITIES.length}] ${city.name.padEnd(25)}`)
    try {
      const count = await crawlCity(city)
      grandTotal += count
      console.log(`\r[${String(i+1).padStart(2,'0')}/${UK_CITIES.length}] ${city.name.padEnd(25)} ✓ ${count} shops`)
    } catch (err: any) {
      console.log(`\r[${String(i+1).padStart(2,'0')}/${UK_CITIES.length}] ${city.name.padEnd(25)} ⚠ error: ${err.message}`)
    }
    await sleep(1000)
  }

  console.log('\n' + '━'.repeat(50))
  console.log(`✅  Crawl complete. Total shops upserted: ${grandTotal}`)
  console.log('   Open Supabase → Table Editor → shops to review.')
  console.log('━'.repeat(50) + '\n')
}

main().catch(err => { console.error(err); process.exit(1) })
