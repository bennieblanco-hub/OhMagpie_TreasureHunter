'use client'

import { useState, useCallback } from 'react'
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  InfoWindow,
} from '@vis.gl/react-google-maps'
import { Shop } from '@/lib/types'
// shops passed as prop — import { SHOPS } from '@/lib/data'

const AXBRIDGE = { lat: 51.2897, lng: -2.8174 }

function markerColor(distance: number): string {
  if (distance <= 30) return '#1D9E75'   // green — nearby
  if (distance <= 80) return '#B8860B'   // gold — mid
  return '#6B6A65'                        // grey — far
}

function ShopPopup({ shop, onClose }: { shop: Shop; onClose: () => void }) {
  return (
    <InfoWindow position={{ lat: shop.lat, lng: shop.lng }} onCloseClick={onClose}>
      <div style={{ fontFamily: 'system-ui, sans-serif', maxWidth: 260 }}>
        <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>{shop.name}</div>
        <div style={{ fontSize: 12, color: '#666', marginBottom: 8 }}>
          {shop.address}, {shop.town} · {shop.distance} mi from Axbridge
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, marginBottom: 8 }}>
          {shop.eras.map(era => (
            <span key={era} style={{
              background: '#f0ede6', color: '#555', fontSize: 10,
              padding: '1px 6px', borderRadius: 20,
            }}>
              {era}
            </span>
          ))}
        </div>
        <div style={{ fontSize: 12, color: '#444', marginBottom: 8 }}>{shop.notes}</div>
        {shop.phone && (
          <div style={{ fontSize: 12, marginBottom: 3 }}>
            📞 <a href={`tel:${shop.phone}`} style={{ color: '#1D9E75' }}>{shop.phone}</a>
          </div>
        )}
        {shop.email && (
          <div style={{ fontSize: 12, marginBottom: 3 }}>
            ✉️ <a href={`mailto:${shop.email}`} style={{ color: '#1D9E75' }}>{shop.email}</a>
          </div>
        )}
        {shop.website && (
          <div style={{ fontSize: 12, marginBottom: 3 }}>
            🌐 <a href={shop.website} target="_blank" rel="noreferrer" style={{ color: '#1D9E75' }}>
              {shop.website.replace('https://', '').replace('www.', '')}
            </a>
          </div>
        )}
        {shop.openingHours && (
          <div style={{ fontSize: 11, color: '#888', marginTop: 6 }}>
            🕐 {shop.openingHours}
          </div>
        )}
        {!shop.verified && (
          <div style={{ fontSize: 10, color: '#B8860B', marginTop: 6 }}>
            ⚠ Contact info unverified — please confirm before visiting
          </div>
        )}
      </div>
    </InfoWindow>
  )
}

interface MapViewProps { shops: Shop[];
  selectedShop: Shop | null
  onSelectShop: (shop: Shop | null) => void
  filterDistance?: number
}

export default function MapView({ selectedShop, onSelectShop, shops, filterDistance }: MapViewProps) {
  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
  const mapId = process.env.NEXT_PUBLIC_GOOGLE_MAPS_MAP_ID

  const visibleShops = (filterDistance
    ? shops.filter(s => s.distance <= filterDistance)
    : shops

  if (!apiKey) {
    return (
      <div className="flex items-center justify-center h-full rounded-xl"
        style={{ background: 'var(--color-surface)', border: '0.5px solid var(--color-border)' }}>
        <div className="text-center px-8">
          <div className="text-4xl mb-4">🗺</div>
          <p className="text-[14px] font-medium mb-2">Map requires a Google Maps API key</p>
          <p className="text-[12px] mb-4" style={{ color: 'var(--color-muted)' }}>
            Add <code className="bg-gray-100 px-1 rounded">NEXT_PUBLIC_GOOGLE_MAPS_API_KEY</code> to your <code className="bg-gray-100 px-1 rounded">.env.local</code> file
          </p>
          <ol className="text-[11px] text-left space-y-1.5" style={{ color: 'var(--color-muted)' }}>
            <li>1. Go to <strong>console.cloud.google.com</strong></li>
            <li>2. Create a project → Enable <strong>Maps JavaScript API</strong></li>
            <li>3. Create credentials → API key</li>
            <li>4. Also enable <strong>Maps Map ID</strong> for advanced markers</li>
            <li>5. Add both keys to .env.local, restart dev server</li>
          </ol>
        </div>
      </div>
    )
  }

  return (
    <APIProvider apiKey={apiKey}>
      <Map
        defaultCenter={AXBRIDGE}
        defaultZoom={7}
        mapId={mapId || 'ohmagpie-map'}
        gestureHandling="greedy"
        disableDefaultUI={false}
        style={{ width: '100%', height: '100%', borderRadius: '12px' }}
        mapTypeControl={false}
        streetViewControl={false}
        fullscreenControl={false}
      >
        {/* Home marker — Axbridge */}
        <AdvancedMarker position={AXBRIDGE} title="Axbridge (home)">
          <Pin background="#141412" glyphColor="white" borderColor="white" glyph="🏠" />
        </AdvancedMarker>

        {/* Shop markers */}
        {visibleShops.map(shop => (
          <AdvancedMarker
            key={shop.id}
            position={{ lat: shop.lat, lng: shop.lng }}
            title={shop.name}
            onClick={() => onSelectShop(shop)}
          >
            <Pin
              background={markerColor(shop.distance)}
              glyphColor="white"
              borderColor="white"
              scale={selectedShop?.id === shop.id ? 1.3 : 1}
            />
          </AdvancedMarker>
        ))}

        {/* InfoWindow for selected shop */}
        {selectedShop && (
          <ShopPopup shop={selectedShop} onClose={() => onSelectShop(null)} />
        )}
      </Map>
    </APIProvider>
  )
}
