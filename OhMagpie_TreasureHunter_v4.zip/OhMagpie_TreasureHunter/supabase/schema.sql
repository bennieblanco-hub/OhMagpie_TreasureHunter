-- OhMagpie TreasureHunter — Supabase Schema
-- Run this in: Supabase Dashboard → SQL Editor → New query → Run

-- ─── SHOPS ────────────────────────────────────────────────────────────────────
create table if not exists shops (
  id            serial primary key,
  name          text not null,
  address       text,
  town          text,
  county        text,
  postcode      text,
  lat           double precision,
  lng           double precision,
  distance_miles integer,
  eras          text[],
  type          text check (type in ('specialist','market','general')),
  phone         text,
  email         text,
  website       text,
  instagram     text,
  opening_hours text,
  notes         text,
  verified      boolean default false,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ─── FINDS ────────────────────────────────────────────────────────────────────
create table if not exists finds (
  id              serial primary key,
  title           text not null,
  price           integer,
  platform        text,
  era             text,
  status          text default 'New' check (status in ('New','Watching','Saved','Pass')),
  image_url       text,
  url             text,
  search_name     text,
  description     text,
  seller          text,
  condition       text,
  interest_score  integer check (interest_score between 0 and 100),
  interest_reason text,
  found_at        timestamptz default now(),
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ─── SEARCHES ─────────────────────────────────────────────────────────────────
create table if not exists searches (
  id              serial primary key,
  name            text not null,
  keywords        text[],
  platforms       text[],
  min_price       integer default 0,
  max_price       integer default 1000,
  active          boolean default true,
  last_run        timestamptz,
  results_today   integer default 0,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ─── INTERACTIONS (learning engine) ───────────────────────────────────────────
create table if not exists interactions (
  id          serial primary key,
  find_id     integer references finds(id) on delete set null,
  find_title  text,
  find_price  integer,
  find_era    text,
  action      text check (action in ('save','watch','pass')),
  created_at  timestamptz default now()
);

-- ─── INDEXES ──────────────────────────────────────────────────────────────────
create index if not exists finds_status_idx    on finds(status);
create index if not exists finds_era_idx       on finds(era);
create index if not exists interactions_era_idx on interactions(find_era);
create index if not exists interactions_action_idx on interactions(action);
create index if not exists shops_distance_idx  on shops(distance_miles);

-- ─── UPDATED_AT TRIGGER ───────────────────────────────────────────────────────
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create or replace trigger shops_updated_at
  before update on shops
  for each row execute function update_updated_at();

create or replace trigger finds_updated_at
  before update on finds
  for each row execute function update_updated_at();

create or replace trigger searches_updated_at
  before update on searches
  for each row execute function update_updated_at();

-- ─── ROW LEVEL SECURITY ───────────────────────────────────────────────────────
alter table shops        enable row level security;
alter table finds        enable row level security;
alter table searches     enable row level security;
alter table interactions enable row level security;

-- Allow all reads (this is a private personal app)
create policy "allow_all_reads"  on shops        for select using (true);
create policy "allow_all_reads"  on finds        for select using (true);
create policy "allow_all_reads"  on searches     for select using (true);
create policy "allow_all_reads"  on interactions for select using (true);

-- Allow all writes (service role handles inserts from the app)
create policy "allow_all_writes" on shops        for all using (true);
create policy "allow_all_writes" on finds        for all using (true);
create policy "allow_all_writes" on searches     for all using (true);
create policy "allow_all_writes" on interactions for all using (true);
