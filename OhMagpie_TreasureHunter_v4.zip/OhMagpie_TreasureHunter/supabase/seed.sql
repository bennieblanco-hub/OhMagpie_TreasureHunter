-- OhMagpie TreasureHunter — Seed Data
-- Run AFTER schema.sql
-- Supabase Dashboard → SQL Editor → New query → Run

-- ─── SHOPS ────────────────────────────────────────────────────────────────────
insert into shops (name, address, town, county, postcode, lat, lng, distance_miles, eras, type, phone, email, website, opening_hours, notes, verified) values

('Bristol Jewellery Company', '40 The Mall, Clifton Village', 'Bristol', 'Bristol', 'BS8 4DS', 51.4567, -2.6186, 16, array['Victorian','Edwardian','Art Deco','General'], 'specialist', null, null, 'https://bristoljewellerycompany.com', 'Mon–Sat 10am–5pm', 'Independent specialist, 35 years in the trade. Covers all precious metals and stones. Buys and sells.', true),

('Wells Antique Centre', 'The Old Corn Exchange, Market Place', 'Wells', 'Somerset', 'BA5 2RB', 51.2094, -2.6474, 10, array['Victorian','Georgian','Edwardian','General'], 'market', '01749 672784', null, null, 'Mon–Sat 10am–5pm, Sun 11am–4pm', 'Multi-dealer centre in a converted corn exchange. Strong jewellery section, good turnover.', true),

('Glastonbury Antiques Centre', '2a Magdalene Street', 'Glastonbury', 'Somerset', 'BA6 9EW', 51.1431, -2.7162, 11, array['Victorian','Art Nouveau','General'], 'market', '01458 834386', null, null, 'Mon–Sat 10am–5pm', 'Eclectic mix. Good for unusual Victorian and Arts & Crafts pieces.', false),

('Holts Jewellery', 'Georgian Townhouse, Bath City Centre', 'Bath', 'Somerset', 'BA1 1', 51.3818, -2.3595, 22, array['Victorian','Art Nouveau','Edwardian','Art Deco'], 'specialist', null, 'email@holtsjewellery.co.uk', 'https://www.holtsjewellery.co.uk', 'By appointment', 'Appointment-based showroom in a Georgian townhouse. Melissa hand-picks every piece. Virtual appointments available.', true),

('Bartlett Street Antiques Centre', '8 Bartlett Street', 'Bath', 'Somerset', 'BA1 2QZ', 51.3824, -2.3596, 22, array['Georgian','Victorian','Regency','Edwardian'], 'market', '01225 443536', null, 'https://www.bartlettstreetantiquescentre.com', 'Mon–Sat 10am–5pm', '5th decade running. Working goldsmith on site. Simon Millard FGA (01225 469785) and M.I. Clarke Jewellery (01225 469570) are the jewellery specialists.', true),

('Nigel Dando Fine Jewellers', 'Pulteney Bridge', 'Bath', 'Somerset', 'BA2 4AX', 51.3807, -2.3580, 22, array['Victorian','Edwardian','Art Deco','General'], 'specialist', null, null, 'https://nigeldando.co.uk', 'Mon–Sat 9:30am–5:30pm', '50+ years experience. Stock changes extremely frequently. Pulteney Bridge location. Worth calling ahead.', true),

('Charles Hart Jewellers (Vintage Tom)', 'Frome Town Centre', 'Frome', 'Somerset', 'BA11', 51.2295, -2.3196, 18, array['Georgian','Victorian','Edwardian','Art Deco','Art Nouveau'], 'specialist', '01373 462089', null, 'https://vintagetom.co.uk', 'Mon–Sat 9:30am–4:30pm', 'Trading for 200+ years. NAG members. Also sells via eBay. Excellent for all eras.', true),

('Taunton Antiques Market', '27 Silver Street', 'Taunton', 'Somerset', 'TA1 3DH', 51.0153, -3.1014, 21, array['Victorian','Edwardian','General'], 'market', '01823 289327', null, null, 'Mon–Sat 9am–5pm', 'Town centre market. Good regular turnover. Worth visiting monthly.', false),

('Clifton Antiques Market', '26 The Mall', 'Bristol', 'Bristol', 'BS8 4JG', 51.4565, -2.6190, 16, array['Victorian','Art Deco','Edwardian'], 'market', '0117 974 1627', null, null, 'Mon–Sat 10am–5pm', 'Premium Clifton Village market. Good Art Deco and Edwardian pieces.', true),

('Great Western Antique Centre', 'Bartlett Street', 'Bath', 'Somerset', 'BA1 2QZ', 51.3822, -2.3600, 22, array['Victorian','Georgian','Art Deco','Edwardian','General'], 'market', null, null, null, 'Mon–Sat 10am–5pm, Sun 11am–4pm', '250+ dealers across multiple floors. Large dedicated jewellery section. Strong turnover.', false),

('Malthouse Antiques', 'Market Place', 'Tetbury', 'Gloucestershire', 'GL8 8DD', 51.6397, -2.1595, 35, array['Georgian','Victorian','Regency'], 'specialist', null, null, null, 'Mon–Sat 10am–5pm', 'Cotswolds specialist. Estate jewellery. Good Georgian.', false),

('Cirencester Antique Market', 'The Corn Hall, Market Place', 'Cirencester', 'Gloucestershire', 'GL7 2NY', 51.7196, -1.9672, 38, array['Georgian','Victorian','Edwardian'], 'market', '01285 644542', null, null, 'Mon–Sat 9am–5pm', 'Cotswolds dealer network. Strong Georgian and Victorian. Regular market days.', false),

('Exeter Antiques Centre', 'The Quay', 'Exeter', 'Devon', 'EX2 4AN', 50.7184, -3.5345, 52, array['Victorian','Edwardian','Art Deco'], 'market', null, null, null, 'Mon–Sun 10am–5pm', 'Regional hub on the quayside. Strong silver section. Good Art Deco.', false),

('Cheltenham Antiques Market', 'Suffolk Road', 'Cheltenham', 'Gloucestershire', 'GL50 2AQ', 51.8994, -2.0783, 56, array['Georgian','Victorian','Art Deco','Regency'], 'market', '01242 529812', null, null, 'Mon–Sat 9:30am–5pm', 'High-end Regency and Georgian pieces reflecting the town''s heritage.', false),

('Oxford Antiques and Collectors Centre', '26 Park End Street', 'Oxford', 'Oxfordshire', 'OX1 1HU', 51.7520, -1.2630, 68, array['Georgian','Victorian','Art Deco','Modern'], 'market', null, null, null, 'Mon–Sat 10am–5pm', 'Large multi-dealer centre. Mix of academic and decorative pieces. Covered Market also worth visiting.', false),

('Gray''s Antique Market', '58 Davies Street, Mayfair', 'London', 'London', 'W1K 5LP', 51.5120, -0.1496, 136, array['Georgian','Victorian','Art Deco','Edwardian','Art Nouveau','Modern'], 'market', '020 7629 7034', null, 'https://www.graysantiques.com', 'Mon–Fri 10am–6pm', 'Premier London antique market. 200+ specialist dealers. Charlotte Sayers (Stand 313-315) exceptional for Stuart through Edwardian.', true),

('The Antique Jewellery Company', 'AJC Townhouse, Mayfair', 'London', 'London', 'W1', 51.5104, -0.1497, 136, array['Georgian','Victorian','Edwardian','Art Deco','Art Nouveau'], 'specialist', null, null, 'https://www.antiquejewellerycompany.com', 'By appointment', 'Founded by Olly. 45+ years. One of London''s best-kept secrets. Appointment townhouse. Exceptional provenance.', true),

('Berganza', 'Hatton Garden', 'London', 'London', 'EC1N 8AA', 51.5186, -0.1085, 135, array['Georgian','Victorian','Edwardian','Art Deco'], 'specialist', null, null, 'https://www.berganza.com', 'Mon–Fri 10am–5:30pm, Sat 10am–4pm', '70+ years in the trade. One of the finest collections in the world. Exceptional Victorian and Edwardian.', true),

('Alfies Antique Market', '13-25 Church Street, Marylebone', 'London', 'London', 'NW8 8DT', 51.5245, -0.1622, 136, array['Art Deco','Edwardian','Art Nouveau','Modern'], 'market', '020 7723 6066', null, 'https://www.alfiesantiques.com', 'Tue–Sat 10am–6pm', 'Strong 20th C. jewellery floor. Good Art Deco and Arts & Crafts. Rooftop café.', true),

('Portobello Road Market', 'Portobello Road, Notting Hill', 'London', 'London', 'W11 2QB', 51.5172, -0.2042, 137, array['Victorian','Edwardian','Art Deco','General'], 'market', null, null, null, 'Saturday only, 7am–3pm', 'Saturday only, 7am–3pm. Volume play — patience rewarded. Go early. Hundreds of dealers.', true),

('Camden Passage', 'Camden Passage, Islington', 'London', 'London', 'N1 8EA', 51.5365, -0.1041, 138, array['Victorian','Georgian','Art Deco','Art Nouveau'], 'market', null, null, null, 'Wed & Sat 8am–6pm', 'Wednesday and Saturday markets. Excellent for Georgian and Art Nouveau. Multiple specialist dealers.', true),

('Bermondsey Antique Market', 'Bermondsey Square', 'London', 'London', 'SE1 3UN', 51.4984, -0.0721, 137, array['Georgian','Victorian','General'], 'market', null, null, null, 'Friday 6am–2pm only', 'Friday 6am–2pm only. Serious trade market. Go at dawn for the best pieces.', true),

('Brighton Lanes Antique Market', 'The Lanes', 'Brighton', 'East Sussex', 'BN1 1HH', 50.8195, -0.1372, 114, array['Victorian','Art Deco','Edwardian','Art Nouveau'], 'market', null, null, null, 'Mon–Sat 10am–5pm', 'Dense cluster of antique jewellery dealers in The Lanes. Worth a day trip.', false),

('Birmingham Jewellery Quarter', 'Vyse Street & Frederick Street', 'Birmingham', 'West Midlands', 'B18 6HA', 52.4883, -1.9141, 101, array['Victorian','Edwardian','Modern'], 'specialist', null, null, null, 'Mon–Sat 9am–5pm', 'Manufacturing heritage district. Multiple dealers and workshops. Strong for estate pieces.', false),

('Butter Lane Antiques', 'Manchester City Centre', 'Manchester', 'Greater Manchester', 'M1', 53.4808, -2.2426, 165, array['Victorian','Art Deco','Art Nouveau','General'], 'specialist', null, null, 'https://www.butterlaneantiques.com', 'Check website', 'Specialist in English antique jewellery and curiosities. Online and in-person.', true),

('Wharfedale Antiques', 'Ilkley Town Centre', 'Ilkley', 'Yorkshire', 'LS29', 53.9250, -1.8309, 195, array['Victorian','Georgian','Edwardian','Art Deco'], 'specialist', null, null, 'https://www.wharfedaleantiques.com', 'Check website', 'Family-run. Strong Yorkshire dealer network. XRF tested pieces.', true),

('York Antique Centre', '2 Lendal', 'York', 'Yorkshire', 'YO1 8AA', 53.9590, -1.0815, 196, array['Victorian','Georgian','Edwardian'], 'market', null, null, null, 'Mon–Sat 10am–5pm', 'Strong Northern dealer network. Good Victorian silver and jewellery.', false),

('Edinburgh Antique Dealers', 'Grassmarket & Victoria Street', 'Edinburgh', 'Edinburgh', 'EH1 2JR', 55.9477, -3.1930, 312, array['Georgian','Victorian','Scottish'], 'specialist', null, null, null, 'Mon–Sat 10am–5pm', 'Quality Georgian and Scottish jewellery. Multiple specialists on Grassmarket and Victoria Street.', false)

on conflict do nothing;

-- ─── SEARCHES ─────────────────────────────────────────────────────────────────
insert into searches (name, keywords, platforms, min_price, max_price, active, results_today) values
('Victorian seed pearl',   array['seed pearl brooch','seed pearl necklace','seed pearl ring victorian','seed pearl and gold'], array['eBay'], 20, 300, true, 4),
('Georgian rings',         array['georgian ring gold','mourning ring 18th century','posy ring antique','georgian gold ring'], array['eBay','Etsy'], 50, 800, true, 2),
('Art Deco paste',         array['art deco paste necklace','art deco paste brooch','art deco rhinestone silver','art deco marcasite'], array['eBay','Etsy'], 15, 250, true, 3),
('Edwardian silver',       array['edwardian silver brooch','edwardian silver pendant','edwardian silver bar pin'], array['eBay'], 30, 400, true, 1),
('Victorian coral and gold', array['victorian coral brooch','antique coral gold','carved coral jewellery antique'], array['eBay','Etsy'], 50, 600, false, 0),
('Turquoise antique',      array['victorian turquoise ring','antique turquoise and pearl','turquoise forget-me-not'], array['eBay'], 30, 350, true, 2),
('Mourning jewellery',     array['victorian mourning brooch','jet brooch victorian','hair locket mourning','whitby jet'], array['eBay','Etsy'], 25, 500, false, 0),
('Enamel and gold',        array['victorian enamel brooch gold','guilloché enamel antique','georgian enamel locket','antique enamel pendant'], array['eBay','Etsy'], 40, 600, true, 1)

on conflict do nothing;
